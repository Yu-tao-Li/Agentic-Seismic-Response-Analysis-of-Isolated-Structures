function k_matric = FormKMatric(k_list, freedom)
% Transcribed from Appendix 1 of the Cui book.
k_matric = zeros(freedom, freedom);
k_matric(1, 1) = k_list(1) + k_list(2);
k_matric(1, 2) = -k_list(2);
for i = 2:freedom-1
    k_matric(i, i) = k_list(i) + k_list(i+1);
    k_matric(i, i-1) = -k_list(i);
    k_matric(i, i+1) = -k_list(i+1);
end
k_matric(freedom, freedom) = k_list(freedom);
k_matric(freedom, freedom-1) = -k_list(freedom);
end
