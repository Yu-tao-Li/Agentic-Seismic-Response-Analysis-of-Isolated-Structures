EDITORIAL-ONLY REVIEW MATERIAL — NOT FOR PUBLICATION (TEMPORARY HOSTING)

This directory contains the book-page images, MATLAB transcription and helper
functions, exported response histories, and the Northridge input record used
for the independent Example 5 verification described in the response letter.

TEMPORARY HOSTING NOTICE: this package is temporarily placed in the root of
the public GitHub repository so that the editor and reviewers can access it
during the ongoing peer-review process. It is intended for review only; it is
not for publication or public supplementary material, and it will be removed
from the repository once the review process is complete. The book source and
page images remain copyrighted by the original publisher.

The MATLAB copies use a package-relative input path so that an editor can
inspect or rerun the files after extraction. The numerical algorithm and
transcribed code are unchanged; only the input-file location was made portable.
