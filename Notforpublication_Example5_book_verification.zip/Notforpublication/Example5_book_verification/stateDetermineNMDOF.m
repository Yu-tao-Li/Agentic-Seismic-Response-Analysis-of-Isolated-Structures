function [force, stiffness] = stateDetermineNMDOF(lastRs, lastDisp, disp_now)
% Transcribed from Appendix 6 of the Cui book.
global fy k0 b
freedom = length(k0);
lastRelativeDisp = zeros(freedom, 1);
relativeDisp = zeros(freedom, 1);
shear = zeros(freedom, 1);
lastShear = zeros(freedom, 1);
force = zeros(freedom, 1);

for i = 1:freedom
    for j = i:freedom
        lastShear(i) = lastShear(i) + lastRs(j);
    end
end

for i = 1:freedom
    if i == 1
        lastRelativeDisp(i) = lastDisp(i);
        relativeDisp(i) = disp_now(i);
    else
        lastRelativeDisp(i) = lastDisp(i) - lastDisp(i-1);
        relativeDisp(i) = disp_now(i) - disp_now(i-1);
    end

    fy1Minusb = fy(i) * (1-b(i));
    ksh = b(i) * k0(i);
    dDisp = relativeDisp(i) - lastRelativeDisp(i);

    c1 = ksh * relativeDisp(i);
    c2 = 1.0 * fy1Minusb;
    c3 = 1.0 * fy1Minusb;
    c = lastShear(i) + k0(i) * dDisp;
    shear(i) = max((c1-c2), min(c1+c3, c));

    if abs(shear(i)-c) < 1e-3
        stiffness(i) = k0(i);
    else
        stiffness(i) = ksh;
    end
end

for i = 1:freedom
    if i == freedom
        force(i) = shear(i);
    else
        force(i) = shear(i) - shear(i+1);
    end
end
end
