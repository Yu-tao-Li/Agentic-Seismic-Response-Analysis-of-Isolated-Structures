NOT FOR PUBLICATION / REVIEW-ONLY MATERIAL (TEMPORARY HOSTING)

Purpose
-------
These files document the local reproduction of Example 5 from the book
“结构地震反应分析编程与软件应用” (Cui et al., 2022). They are provided as
reviewer-response evidence only. This package is temporarily hosted in the
repository root during the ongoing peer-review process; it is not part of
the permanent public GitHub release.

Files
-----
- Example5_book_OCR.m: MATLAB transcription of Section 11.3.1, PDF pages
  276–280 (printed pages 265–269), with output export added for verification.
- FormKMatric.m: transcription of Appendix 1, PDF page 351 (printed page 340).
- stateDetermineNMDOF.m: transcription of Appendix 6, PDF pages 354–355
  (printed pages 343–344).
- Example5_book_OCR_normalized.m: verification variant using the same
  algorithm but normalizing the Northridge record to PGA = 0.40 g, matching
  the current GitHub Example 5 workflow.
- book_*_normalized.txt: response histories exported from the independent
  normalized run and used for the revised comparison metrics.
- book_pdf_*.png: page images used for the transcription.

The book source is copyrighted. The MATLAB files and page images are retained
here solely for editorial/reviewer verification during peer review. This
package is NOT for publication, must not be reused or redistributed, and will
be removed from the repository once the review process is complete.

Direct book scaling uses ug = 25.27*data(:,1)'. The normalized verification
variant uses the same book algorithm with a 0.40-g record; under that common
input definition, its responses reproduce the archived GitHub comparison
series to numerical precision.
