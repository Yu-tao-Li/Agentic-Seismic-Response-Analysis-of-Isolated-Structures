# Example 5 OCR reproduction

The main program was transcribed from the Cui book, Section 11.3.1 (PDF pages 276–280; printed pages 265–269). The helper functions were transcribed from Appendix 1 (PDF page 351; printed page 340) and Appendix 6 (PDF pages 354–355; printed pages 343–344).

MATLAB: `D:\MatlabR2025b\bin\matlab.exe` (R2025b)

Input: `Northridge_01_NO_968.txt`, 1900 samples, `dt=0.01 s`.

## Direct book run

The book line `ug=25.27*data(:,1)'` was retained. The run used `n2=3500` and completed without an error.

| output | maximum |
|---|---:|
| top displacement | 28.676452509 mm |
| top acceleration | 5174.72 mm/s^2 |
| base shear | 534289.2194 N |

These values are consistent with the ranges shown in the book's Figures 11-27–11-29.

## Why the existing external trace is slightly different

The existing harness implementation normalizes the record to `0.40 g` before integration. The raw record peak is 158.281, so the book scaling gives 3999.76087 mm/s^2 (`0.4078621 g`), while the normalized run uses 3924 mm/s^2. This is a factor of 0.9810586501.

Keeping the book integrator and both appendix functions unchanged, but using the harness's 0.40-g normalization, gives:

| output | maximum |
|---|---:|
| top displacement | 28.1488123009 mm |
| top acceleration | 5079.1572381 mm/s^2 |
| base shear | 532869.1718 N |

Those normalized outputs match the exported `gpt5.opju` reference files (after unit conversion and the reference file's decimal formatting) with maximum absolute differences of:

* top displacement: `5.65e-13 m`
* top acceleration: `5.01e-11 m/s^2`
* isolator hysteresis displacement: `5.63e-13 m`
* isolator hysteresis force: `5.39e-06 N`

Therefore the current `gpt5.opju` traces are reproducible from the book algorithm, but their input is the 0.40-g normalized record rather than the book's literal `25.27*data(:,1)` scaling.

## Revised comparison metrics

Using the independently executed normalized series directly against the
corrected harness MATLAB output over the common 0.00--18.99 s interval gives
maximum absolute differences of `1.18e-13 m` for top displacement,
`2.96e-12 m/s^2` for top acceleration, and `1.19e-6 N` for isolator force.
The maximum peak relative error is `4.18e-12`, the maximum NRMSE is `1.73e-12`,
and the hysteresis-loop area relative error is `3.74e-13`.
