% OCR transcription of Example 5 (Cui book, Section 11.3.1) with output save.
clear; clc;
format shortEng

m = [250, 270, 270, 180];
freedom = length(m);
input_file = fullfile(fileparts(mfilename('fullpath')), 'input_data', 'Northridge_01_NO_968.txt');
data = load(input_file);
raw = data(:,1)'; ug = raw * (1000*0.40*9.81 / max(abs(raw))); 
n1 = length(ug);
dt = 0.01;

global fy k0 b
fy = 1e3 * [500, 1225, 975, 490];
k0 = 1e3 * [50, 245, 195, 98];
b = [0.05, 0, 0, 0];

M = zeros(freedom, freedom);
for i = 1:freedom
    M(i,i) = m(i);
end
K = FormKMatric(k0, freedom);
[eig_vec, eig_val] = eig(inv(M) * K);
[w, w_order] = sort(sqrt(diag(eig_val)));
mode = eig_vec(:, w_order);
for i = 1:freedom
    mode(:,i) = mode(:,i) / mode(freedom,i);
end
T = zeros(1, freedom);
for i = 1:freedom
    T(i) = 2*pi/w(i);
end
A = 2*0.05/(w(1)+w(2))*[w(1)*w(2); 1];
C = A(1)*M + A(2)*K;
gama = 0.5; beta = 0.25;
AA1 = M/(beta*dt) + (gama/beta)*C;
AA2 = M/(2*beta) + dt*(gama/2/beta-1)*C;

n2 = 3500;
Time = zeros(1, n2); Time(1,1) = 0;
u = zeros(freedom, n2); u(:,1) = 0;
v = zeros(freedom, n2); v(:,1) = 0;
P = zeros(freedom, n2); P(:,1) = -ug(1,1)*m';
Rs = zeros(freedom, n2); Rs(:,1) = 0;
k = zeros(freedom, n2); k(:,1) = k0';
aa = zeros(freedom, n2);
aa(:,1) = inv(M) * (P(:,1)-C*v(:,1)-Rs(:,1));
utrial0 = zeros(freedom, 1);
utrial = zeros(freedom, 1);
Rtrial = zeros(freedom, 1);
ktrial = zeros(freedom, 1);

for j = 2:n2
    Time(1,j) = (j-1)*dt;
    K = FormKMatric(k(:,j-1), freedom);
    KK = K + 1/(beta*dt^2)*M + gama/(beta*dt)*C;
    if j <= n1
        P(:,j) = -ug(1,j)*m';
    else
        ug(1,j) = 0;
        P(:,j) = 0;
    end
    dltP(:,j-1) = P(:,j)-P(:,j-1);
    dltPP(:,j-1) = dltP(:,j-1) + AA1*v(:,j-1) + AA2*aa(:,j-1);
    utrial0 = u(:,j-1);
    Rtrial0 = Rs(:,j-1);
    dltR_0 = dltPP(:,j-1);
    KKt_0 = KK;
    while sum(abs(dltR_0)) > 1e-5
        dltu = inv(KKt_0) * dltR_0;
        utrial = utrial0 + dltu;
        [Rtrial, ktrial] = stateDetermineNMDOF(Rtrial0, utrial0, utrial);
        K = FormKMatric(ktrial, freedom);
        KKt_0 = K + 1/(beta*dt^2)*M + gama/(beta*dt)*C;
        dltF = Rtrial-Rtrial0 + ((gama/beta/dt)*C + (1/beta/dt^2)*M)*dltu;
        dltR_0 = dltR_0 - dltF;
        utrial0 = utrial;
        Rtrial0 = Rtrial;
    end
    u(:,j) = utrial;
    Rs(:,j) = Rtrial;
    k(:,j) = ktrial;
    dltv = (gama/beta/dt)*(u(:,j)-u(:,j-1)) - (gama/beta)*v(:,j-1) + (1-gama/2/beta)*dt*aa(:,j-1);
    dltaa = (1/beta/dt^2)*(u(:,j)-u(:,j-1)) - (1/beta/dt)*v(:,j-1) - (1/2/beta)*aa(:,j-1);
    v(:,j) = v(:,j-1) + dltv;
    aa(:,j) = aa(:,j-1) + dltaa;
end

fourthShear = Rs(4,:);
thirdShear = Rs(3,:) + Rs(4,:);
secondShear = Rs(2,:) + Rs(3,:) + Rs(4,:);
BaseShear = sum(Rs);
save('book_example5_output_normalized.mat', 'Time', 'u', 'aa', 'Rs', 'BaseShear', 'T', 'w', 'M', 'K', 'C');
dlmwrite('book_top_displacement_normalized.txt', [Time(:), u(4,:)'], 'delimiter', '\t', 'precision', '%.17g');
dlmwrite('book_top_acceleration_normalized.txt', [Time(:), aa(4,:)'], 'delimiter', '\t', 'precision', '%.17g');
dlmwrite('book_isolator_hysteresis_normalized.txt', [u(1,:)', BaseShear(:)], 'delimiter', '\t', 'precision', '%.17g');
disp(['Completed n2=', num2str(n2), ', n1=', num2str(n1)]);
disp(['max_abs_u4=', num2str(max(abs(u(4,:))))]);
disp(['max_abs_aa4=', num2str(max(abs(aa(4,:))))]);
disp(['max_abs_BaseShear=', num2str(max(abs(BaseShear)))]);




